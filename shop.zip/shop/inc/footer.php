</div>
   <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>Information</h4>
						<ul>
						<li><a href="#">About Us</a></li>
						
						<li><a href="contact.php"><span>Contact Us</span></a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Why buy from us</h4>
						<ul>
						<li><a href="contact.php">About Us</a></li>
						<li><a href="#">Customer Service</a></li>
						
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>My account</h4>
						<ul>
							<li><a href="login.php">Sign In</a></li>
							<li><a href="cart.php">View Cart</a></li>
							
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Developd by</h4>
						<ul>
							<li><span><a href='facebook.com/rootkalsa'>Asif Javed</a></span></li>
							
						</ul>
						<div class="social-icons">
							
   	 					</div>
				</div>
			</div>
			
			
			
			<div class="copy_right">
				<p>Fabrics-Emporium | All rights Reseverd </p>
		   </div>
     </div>
    </div>
   </body>
</html>
