-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2022 at 02:07 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminId` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminUser` varchar(255) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminPassword` varchar(32) NOT NULL,
  `level` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminId`, `adminName`, `adminUser`, `adminEmail`, `adminPassword`, `level`) VALUES
(2, 'admin', 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `brandId` int(11) NOT NULL,
  `brandName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`brandId`, `brandName`) VALUES
(1, 'Zellbury'),
(2, 'Limelight'),
(3, 'Zeen Woman Wear'),
(4, 'Sana Safinaz'),
(5, 'Gul Ahmed'),
(6, 'Nishat Linen');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cartId` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cartId`, `sId`, `productId`, `productName`, `price`, `quantity`, `image`) VALUES
(2, '7709o3db173grtqv1p6mj87rh8', 13, 'new design Limelight', 2500.00, 1, 'uploads/faf1d30089.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `catId` int(11) NOT NULL,
  `catName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`catId`, `catName`) VALUES
(1, 'Lown'),
(2, 'Silk'),
(3, 'Lilen'),
(4, 'wash and wear');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_compare`
--

CREATE TABLE `tbl_compare` (
  `id` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `zip` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `address`, `city`, `country`, `zip`, `phone`, `email`, `pass`) VALUES
(2, 'test', 'test ad', 'testcity', 'test pak', '2245', '123565', 'test@gmail.com', '098f6bcd4621d373cade4e832627b4f6'),
(4, 'Muhammad Asif Javed', 'chak no 161 g.b new, tehsil Gojra, District, Toba Tek Singh', 'Gojra', 'Pakistan', '36120', '03434361161', 'tt@gmail.com', '6cee4618fc4960d184eb7efbd0aa27b5');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `catId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `body` text NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`productId`, `productName`, `catId`, `brandId`, `body`, `price`, `image`, `type`) VALUES
(1, 'Noorangi Shaad Digital Printed Lawn', 1, 5, '<ul data-mce-fragment=\"1\">\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Parrot Green - Dhaani</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn front 1.5 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn back 1.5 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn sleeves : 0.65 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Dyed Lawn trouser:2.5 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn dupata: 2.5meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Embroidery neckline patch on organza</span></p>\r\n</li>\r\n</ul>', 4450.00, 'uploads/6229bb8c6c.jpg', 0),
(2, 'Digital Printed Lawn Unstitched 3Pc', 2, 5, '<p><span style=\"font-size: small;\"><label>Product Code:</label>&nbsp;Shaad - Akhraaz</span></p>\r\n<div class=\"product-inventory\"><span style=\"font-size: small;\"><label>Availability:</label>&nbsp;In stock</span></div>\r\n<div class=\"product-type\"><span style=\"font-size: small;\"><label>Product Type:</label>&nbsp;Women\'s Unstitched Clothing</span></div>', 4450.00, 'uploads/d0bd21b05d.jpg', 1),
(3, 'Zellbury Winter Unstitched Khaddar Printed 1PC Shirt', 1, 1, '<p><span style=\"font-size: small;\">Brand: Zellbury</span><br /><span style=\"font-size: small;\">Product Code: WUW21X10092</span><br /><span style=\"font-size: small;\">Availability: In stock</span><br /><span style=\"font-size: small;\">Product Type: Women\'s Unstitched Clothing</span></p>', 990.00, 'uploads/a2e13f39d6.jpg', 1),
(5, 'Vasl-e-Meeras Unstitched Formal 3Pc Suit', 1, 3, '<ul data-mce-fragment=\"1\">\r\n<li><span style=\"font-size: small;\">Embroidered Organza Front</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Organza Back</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Organza Sleeves</span></li>\r\n<li><span style=\"font-size: small;\">Jamawar Dupatta</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Front Plus Back Patch 2</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Sleeves Patch 2</span></li>\r\n<li><span style=\"font-size: small;\">Dyed Raw Silk Trouser</span></li>\r\n</ul>', 8950.00, 'uploads/ec98d06317.jpg', 1),
(6, 'Embroidered Stapple Linen 3Pc Suit ', 3, 3, '<p>Brand: Faisal Fabrics<br />Product: MSV-22416 Pink Azurite<br />Collection: Creaze Volume 05 Embroidered Linen Collection 2022<br />Fabric: Linen</p>\r\n<p>Digital Staple Shirt<br />Embroidered Cutwork Pure Chiffon Dupatta<br />Dyed Trouser</p>', 3750.00, 'uploads/651ae387dc.jpg', 1),
(7, 'Noorangi Shaad Digital Printed Lawn', 1, 5, '<ul data-mce-fragment=\"1\">\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Parrot Green - Dhaani</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn front 1.5 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn back 1.5 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn sleeves : 0.65 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Dyed Lawn trouser:2.5 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn dupata: 2.5meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Embroidery neckline patch on organza</span></p>\r\n</li>\r\n</ul>', 4450.00, 'uploads/c24accb5df.jpg', 1),
(8, 'Vasl-e-Meeras Unstitched Formal 3Pc Suit', 4, 3, '<ul data-mce-fragment=\"1\">\r\n<li><span style=\"font-size: small;\">Embroidered Organza Front</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Organza Back</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Organza Sleeves</span></li>\r\n<li><span style=\"font-size: small;\">Jamawar Dupatta</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Front Plus Back Patch 2</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Sleeves Patch 2</span></li>\r\n<li><span style=\"font-size: small;\">Dyed Raw Silk Trouser</span></li>\r\n</ul>', 8950.00, 'uploads/ba1545595a.jpg', 1),
(9, 'Zeen Woman Unstitched Formal 3Pc Suit', 1, 3, '<ul data-mce-fragment=\"1\">\r\n<li><span style=\"font-size: small;\">Embroidered Organza Front</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Organza Back</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Organza Sleeves</span></li>\r\n<li><span style=\"font-size: small;\">Jamawar Dupatta</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Front Plus Back Patch 2</span></li>\r\n<li><span style=\"font-size: small;\">Embroidered Sleeves Patch 2</span></li>\r\n<li><span style=\"font-size: small;\">Dyed Raw Silk Trouser</span></li>\r\n</ul>', 8950.00, 'uploads/ca080140a4.jpg', 1),
(10, 'Gul Ahmed Shaad Digital Printed Lawn', 1, 5, '<ul data-mce-fragment=\"1\">\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Parrot Green - Dhaani</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn front 1.5 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn back 1.5 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn sleeves : 0.65 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Dyed Lawn trouser:2.5 meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Digital printed lawn dupata: 2.5meter</span></p>\r\n</li>\r\n<li data-mce-fragment=\"1\">\r\n<p><span>Embroidery neckline patch on organza</span></p>\r\n</li>\r\n</ul>', 4450.00, 'uploads/2f53cc1a85.jpg', 0),
(12, 'new 2022 design', 1, 6, '<p><span style=\"font-size: small;\">New 2020 Pakistani Girls Dress Design</span></p>', 2300.00, 'uploads/16eb0fac03.jpg', 1),
(13, 'new design Limelight', 2, 2, '<h1 class=\"jeg_post_title\"><span style=\"font-size: small;\">Stylish and Beautiful Dresses</span></h1>\r\n<h1 class=\"jeg_post_title\"><span style=\"font-size: small;\">for Girls in Pakistan</span></h1>', 2500.00, 'uploads/faf1d30089.jpg', 0),
(15, 'Sana Safinaz Muzlin', 3, 4, '<p>new latest design</p>', 2200.00, 'uploads/d057178b3b.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_seller`
--

CREATE TABLE `tbl_seller` (
  `adminId` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminUser` varchar(255) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminPassword` varchar(32) NOT NULL,
  `level` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_seller`
--

INSERT INTO `tbl_seller` (`adminId`, `adminName`, `adminUser`, `adminEmail`, `adminPassword`, `level`) VALUES
(2, 'admin', 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_wlist`
--

CREATE TABLE `tbl_wlist` (
  `id` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`brandId`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cartId`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `tbl_compare`
--
ALTER TABLE `tbl_compare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `tbl_seller`
--
ALTER TABLE `tbl_seller`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `tbl_wlist`
--
ALTER TABLE `tbl_wlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `brandId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_compare`
--
ALTER TABLE `tbl_compare`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_seller`
--
ALTER TABLE `tbl_seller`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_wlist`
--
ALTER TABLE `tbl_wlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
